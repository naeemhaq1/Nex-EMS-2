# NEXLINX EMS - COMPREHENSIVE INTERFACE ENDPOINT MAPPING

**Version:** 1.0  
**Date:** August 1, 2025  
**Purpose:** Complete mapping of all interface elements to their corresponding API endpoints for both desktop and mobile versions  

---

## TABLE OF CONTENTS

1. [Authentication & Login](#authentication--login)
2. [Desktop Admin Dashboard](#desktop-admin-dashboard)
3. [Mobile Admin Dashboard](#mobile-admin-dashboard)
4. [Employee Directory & Management](#employee-directory--management)
5. [Monthly Reports & Analytics](#monthly-reports--analytics)
6. [WhatsApp Console](#whatsapp-console)
7. [Mobile Employee Dashboard](#mobile-employee-dashboard)
8. [System Administration](#system-administration)
9. [Attendance Management](#attendance-management)
10. [Settings & Configuration](#settings--configuration)

---

## AUTHENTICATION & LOGIN

### Login Page (`/login`)
**Location:** `client/src/pages/Login.tsx`

| Element | Action | API Endpoint | Method | Description |
|---------|--------|--------------|--------|-------------|
| Login Form | Submit Login | `/api/auth/login` | POST | User authentication with username/password |
| Password Reset Button | Request Reset | `/api/auth/password-reset` | POST | Password reset functionality |
| First Time Password Form | Change Password | `/api/auth/first-time-password` | POST | First-time password change |

---

## DESKTOP ADMIN DASHBOARD

### Main Dashboard (`/admin/dashboard`)
**Location:** `client/src/pages/DesktopAdminDashboard.tsx`

| Element | Action | API Endpoint | Method | Description |
|---------|--------|--------------|--------|-------------|
| Dashboard Metrics Cards | Load Metrics | `/api/admin/dashboard-metrics` | GET | System metrics (users, attendance, performance) |
| System Status Widget | Load Status | `/api/admin/system-metrics` | GET | Server health, uptime, CPU, memory usage |
| Services Monitor | Load Services | `/api/admin/services` | GET | Three-tier service status monitoring |
| Announcements Panel | Load Announcements | `/api/announcements` | GET | System-wide announcements |
| Send Announcement Button | Send Message | `/api/announcements/send` | POST | Send system-wide announcements |
| Employee Locations Map | Load Locations | `/api/admin/employee-locations` | GET | Real-time employee location data |
| 48-Hour Punch Chart | Load Punch Data | `/api/admin/punch-48hour-data` | GET | Hourly punch-in/out statistics |
| Refresh Button | Refresh Data | Multiple endpoints | GET | Refreshes all dashboard data |

### Navigation Menu Items

| Menu Item | Route | Primary Endpoint | Description |
|-----------|-------|------------------|-------------|
| Employee Management | `/employee-directory` | `/api/employees` | Employee CRUD operations |
| Attendance Records | `/attendance-records` | `/api/attendance/records` | Attendance tracking and monitoring |
| Monthly Reports | `/monthly-report-table` | `/api/admin/monthly-report/july-2025-full` | Comprehensive monthly reports |
| WhatsApp Console | `/whatsapp-console` | `/api/whatsapp/*` | WhatsApp management interface |
| Analytics | `/admin-analytics` | `/api/analytics/*` | Advanced analytics dashboard |
| System Settings | `/settings` | `/api/settings/*` | System configuration |

---

## MOBILE ADMIN DASHBOARD

### Mobile Dashboard (`/mobile/admin/dashboard`)
**Location:** `client/src/pages/mobile/MobileAdminDashboard.tsx`

| Element | Action | API Endpoint | Method | Description |
|---------|--------|--------------|--------|-------------|
| Quick Actions Grid | Navigation | Various routes | - | Quick access to admin functions |
| Metrics Overview | Load Metrics | `/api/admin/dashboard-metrics` | GET | Mobile-optimized metrics display |
| Employee Management Card | Navigate | `/mobile/admin/employees` | - | Employee management interface |
| Attendance Control Card | Navigate | `/mobile/admin/attendance` | - | Attendance monitoring |
| Analytics Card | Navigate | `/mobile/admin/analytics` | - | Mobile analytics dashboard |
| System Monitoring Card | Navigate | `/mobile/admin/service-monitoring-new` | - | Service health monitoring |
| Device Management Card | Navigate | `/mobile/admin/devices` | - | Device and session management |
| Employee Map Card | Navigate | `/mobile/admin/map` | - | Employee location tracking |

---

## EMPLOYEE DIRECTORY & MANAGEMENT

### Employee Directory (`/employee-directory`)
**Location:** `client/src/pages/EmployeeDirectory.tsx`

| Element | Action | API Endpoint | Method | Description |
|---------|--------|--------------|--------|-------------|
| Employee List Table | Load Employees | `/api/employees` | GET | Complete employee data |
| Search Input | Filter Employees | `/api/employees/search` | GET | Employee search functionality |
| Department Filter | Filter by Dept | `/api/employees?department=X` | GET | Department-based filtering |
| Add Employee Button | Create Employee | `/api/employees` | POST | New employee creation |
| Edit Employee Button | Update Employee | `/api/employees/:id` | PUT | Employee data modification |
| Delete Employee Button | Remove Employee | `/api/employees/:id` | DELETE | Employee deletion |
| Export CSV Button | Export Data | `/api/employees/export` | GET | Employee data export |
| Import CSV Button | Import Data | `/api/employees/import` | POST | Bulk employee import |
| WhatsApp Contact Button | Send WhatsApp | `/api/whatsapp/send-message` | POST | Direct WhatsApp messaging |
| Profile View Dialog | Load Profile | `/api/employees/:id/profile` | GET | Detailed employee profile |
| Attendance History | Load History | `/api/attendance/employee/:id` | GET | Employee attendance records |

---

## MONTHLY REPORTS & ANALYTICS

### Monthly Report Table (`/monthly-report-table`)
**Location:** `client/src/pages/MonthlyReportTable.tsx`

| Element | Action | API Endpoint | Method | Description |
|---------|--------|--------------|--------|-------------|
| Report Data Table | Load Report Data | `/api/admin/monthly-report/july-2025-full` | GET | Complete 309 employee report |
| Search Bar | Filter Employees | Client-side filtering | - | Real-time table filtering |
| Department Filter | Filter by Dept | Client-side filtering | - | Department-based filtering |
| Sort Controls | Sort Data | Client-side sorting | - | Column-based sorting |
| Generate Email Report | Send Email | `/api/admin/generate-hours-report` | POST | Email comprehensive report |
| Generate Accurate Report | Send Accurate Email | `/api/admin/generate-accurate-hours-report` | POST | Corrected business rules report |
| Export CSV Button | Download CSV | `/api/admin/monthly-report/export` | GET | Report data export |

### Analytics Dashboard (`/admin-analytics`)
**Location:** `client/src/pages/AdminAnalytics.tsx`

| Element | Action | API Endpoint | Method | Description |
|---------|--------|--------------|--------|-------------|
| Performance Charts | Load Analytics | `/api/analytics/performance` | GET | Performance metrics visualization |
| Attendance Charts | Load Attendance | `/api/analytics/attendance` | GET | Attendance trend analysis |
| Department Stats | Load Dept Stats | `/api/analytics/departments` | GET | Department-wise analytics |
| Refresh Analytics | Refresh Data | `/api/analytics/refresh` | POST | Analytics data refresh |

---

## WHATSAPP CONSOLE

### WhatsApp Console (`/whatsapp-console`)
**Location:** `client/src/pages/WhatsAppStunningConsole.tsx`

| Element | Action | API Endpoint | Method | Description |
|---------|--------|--------------|--------|-------------|
| Contact List | Load Contacts | `/api/whatsapp/contacts` | GET | WhatsApp contact directory |
| Message History | Load Messages | `/api/whatsapp/messages/:conversationId` | GET | Conversation message history |
| Send Message Button | Send Message | `/api/whatsapp/send-message` | POST | Send WhatsApp message |
| Send Media Button | Send Media | `/api/whatsapp/send-media` | POST | Send media files |
| Queue Management | Load Queue | `/api/whatsapp/queue` | GET | Message queue status |
| Queue Controls | Manage Queue | `/api/whatsapp/queue/control` | POST | Start/stop/pause queue |
| Broadcast Message | Send Broadcast | `/api/whatsapp/broadcast` | POST | Bulk message sending |
| Group Management | Manage Groups | `/api/whatsapp/groups` | GET/POST | WhatsApp group operations |
| Template Messages | Load Templates | `/api/whatsapp/templates` | GET | Message template management |
| Analytics Panel | Load Analytics | `/api/whatsapp/analytics` | GET | WhatsApp usage analytics |
| Health Check | System Health | `/api/whatsapp/health` | GET | WhatsApp service status |

---

## MOBILE EMPLOYEE DASHBOARD

### Employee Dashboard (`/mobile/employee/dashboard`)
**Location:** `client/src/pages/mobile/MobileEmployeeDashboard.tsx`

| Element | Action | API Endpoint | Method | Description |
|---------|--------|--------------|--------|-------------|
| Punch In/Out Button | Record Attendance | `/api/attendance/punch` | POST | Biometric attendance recording |
| Location Services | Update Location | `/api/attendance/location` | POST | GPS location recording |
| Dashboard Metrics | Load Metrics | `/api/employee/dashboard-metrics` | GET | Employee-specific metrics |
| Attendance History | Load History | `/api/attendance/employee/history` | GET | Personal attendance records |
| Schedule View | Load Schedule | `/api/employee/schedule` | GET | Work schedule information |
| Profile Settings | Load Profile | `/api/employee/profile` | GET | Employee profile data |
| Sync Status | Check Sync | `/api/sync/status` | GET | Offline sync status |
| Photo Upload | Upload Photo | `/api/employee/photo` | POST | Profile photo upload |

### Mobile Punch Interface (`/mobile/punch`)
**Location:** `client/src/pages/mobile/MobilePunchInterface.tsx`

| Element | Action | API Endpoint | Method | Description |
|---------|--------|--------------|--------|-------------|
| Punch In Button | Record Punch In | `/api/attendance/punch-in` | POST | Punch in with location |
| Punch Out Button | Record Punch Out | `/api/attendance/punch-out` | POST | Punch out with location |
| Grace Punch | Grace Period Punch | `/api/attendance/grace-punch` | POST | Grace period attendance |
| Location Override | Manual Location | `/api/attendance/manual-location` | POST | Manual location entry |

---

## SYSTEM ADMINISTRATION

### Service Monitoring (`/service-health`)
**Location:** `client/src/pages/ServiceHealthDashboard.tsx`

| Element | Action | API Endpoint | Method | Description |
|---------|--------|--------------|--------|-------------|
| Service Status Cards | Load Services | `/api/admin/services` | GET | Three-tier service status |
| Restart Service Button | Restart Service | `/api/admin/services/:name/restart` | POST | Individual service restart |
| System Logs | Load Logs | `/api/admin/logs` | GET | System log viewing |
| Database Health | Check Database | `/api/admin/database/health` | GET | Database connectivity check |
| Backup Status | Load Backup Info | `/api/admin/backup/status` | GET | Backup system status |

### User Management (`/session-management`)
**Location:** `client/src/pages/SessionManagement.tsx`

| Element | Action | API Endpoint | Method | Description |
|---------|--------|--------------|--------|-------------|
| Active Sessions | Load Sessions | `/api/admin/sessions` | GET | Current user sessions |
| Terminate Session | End Session | `/api/admin/sessions/:id/terminate` | DELETE | Force logout user |
| Device Management | Load Devices | `/api/admin/devices` | GET | Registered devices |
| Trust/Untrust Device | Update Device | `/api/admin/devices/:id/trust` | PUT | Device trust management |

### Settings & Configuration (`/settings`)
**Location:** `client/src/pages/Settings.tsx`

| Element | Action | API Endpoint | Method | Description |
|---------|--------|--------------|--------|-------------|
| System Settings Form | Update Settings | `/api/admin/settings` | PUT | System configuration |
| Timezone Settings | Update Timezone | `/api/admin/timezone` | PUT | Timezone configuration |
| Notification Settings | Update Notifications | `/api/admin/notifications` | PUT | Alert configurations |
| Backup Settings | Update Backup | `/api/admin/backup/settings` | PUT | Backup configuration |

---

## ATTENDANCE MANAGEMENT

### Attendance Records (`/attendance-records`)
**Location:** `client/src/pages/AttendanceRecords.tsx`

| Element | Action | API Endpoint | Method | Description |
|---------|--------|--------------|--------|-------------|
| Attendance Table | Load Records | `/api/attendance/records` | GET | Attendance record listing |
| Date Range Filter | Filter Records | `/api/attendance/records?date_range=X` | GET | Date-based filtering |
| Employee Filter | Filter by Employee | `/api/attendance/records?employee_id=X` | GET | Employee-specific records |
| Manual Adjustment | Update Record | `/api/attendance/records/:id` | PUT | Manual attendance adjustment |
| Export Records | Export Data | `/api/attendance/export` | GET | Attendance data export |

### Biometric Exemptions (`/biometric-exemptions`)
**Location:** `client/src/pages/BiometricExemptions.tsx`

| Element | Action | API Endpoint | Method | Description |
|---------|--------|--------------|--------|-------------|
| Exemption List | Load Exemptions | `/api/attendance/exemptions` | GET | Biometric exemption list |
| Add Exemption | Create Exemption | `/api/attendance/exemptions` | POST | New exemption creation |
| Remove Exemption | Delete Exemption | `/api/attendance/exemptions/:id` | DELETE | Exemption removal |
| Update Calculations | Recalculate | `/api/attendance/recalculate` | POST | Attendance recalculation |

---

## REAL-TIME DATA ENDPOINTS

### Polling & Data Synchronization

| Service | Endpoint | Method | Refresh Rate | Description |
|---------|----------|--------|--------------|-------------|
| Dashboard Metrics | `/api/admin/dashboard-metrics` | GET | 30 seconds | Admin dashboard data |
| System Metrics | `/api/admin/system-metrics` | GET | 30 seconds | Server performance data |
| Service Status | `/api/admin/services` | GET | 30 seconds | Service health monitoring |
| WhatsApp Queue | `/api/whatsapp/queue` | GET | 15 seconds | Message queue status |
| Employee Locations | `/api/admin/employee-locations` | GET | 60 seconds | GPS location updates |
| Attendance Sync | `/api/attendance/sync` | GET | 30 seconds | BioTime data sync |

### Webhook Endpoints

| Service | Endpoint | Method | Purpose |
|---------|----------|--------|---------|
| WhatsApp Webhook | `/api/whatsapp/webhook` | POST | WhatsApp message reception |
| BioTime Webhook | `/api/biotime/webhook` | POST | Attendance data updates |
| System Alerts | `/api/admin/alerts/webhook` | POST | System notification delivery |

---

## MOBILE-SPECIFIC ENDPOINTS

### Mobile API Routes (`/api/mobile/*`)

| Endpoint | Method | Purpose | Used By |
|----------|--------|---------|---------|
| `/api/mobile/dashboard` | GET | Mobile dashboard data | Mobile dashboards |
| `/api/mobile/punch` | POST | Mobile attendance recording | Punch interfaces |
| `/api/mobile/sync` | POST/GET | Offline data synchronization | Sync managers |
| `/api/mobile/location` | POST | GPS location updates | Location services |
| `/api/mobile/photo` | POST | Profile photo uploads | Photo editors |

---

## ERROR HANDLING & STATUS CODES

### Common HTTP Status Codes

| Code | Meaning | Typical Response |
|------|---------|------------------|
| 200 | Success | Data returned successfully |
| 201 | Created | Resource created successfully |
| 400 | Bad Request | Invalid request parameters |
| 401 | Unauthorized | Authentication required |
| 403 | Forbidden | Insufficient permissions |
| 404 | Not Found | Resource not found |
| 500 | Server Error | Internal server error |

### Authentication Flow

1. **Login**: POST `/api/auth/login` → Session cookie set
2. **Session Check**: Middleware validates session on protected routes
3. **Logout**: POST `/api/auth/logout` → Session destroyed
4. **Password Reset**: POST `/api/auth/password-reset` → Email sent

---

## DEPLOYMENT CONSIDERATIONS

### API Base URLs by Environment

| Environment | Base URL | Port Configuration |
|-------------|----------|-------------------|
| Development | `http://localhost:5000` | Main: 5000, Core: 5001, WhatsApp: 5002 |
| Staging | `https://staging.nexlinx.net.pk` | Standard HTTPS |
| Production | `https://ems.nexlinx.net.pk` | Standard HTTPS |

### Critical Performance Endpoints

| Endpoint | Performance Target | Cache Strategy |
|----------|-------------------|----------------|
| `/api/admin/dashboard-metrics` | <500ms | 30-second cache |
| `/api/admin/monthly-report/july-2025-full` | <2000ms | Database-optimized query |
| `/api/whatsapp/contacts` | <300ms | 5-minute cache |
| `/api/employees` | <800ms | Real-time with pagination |

---

## MAINTENANCE & UPDATES

### Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | Aug 1, 2025 | Initial comprehensive mapping |

### Notes for Developers

1. **Always use the exact endpoint paths** listed in this document
2. **Check authentication requirements** before making API calls
3. **Follow the HTTP methods** specified for each endpoint
4. **Implement proper error handling** for all API interactions
5. **Use appropriate refresh rates** for real-time data
6. **Maintain session state** for authenticated requests

---

**Last Updated:** August 1, 2025  
**Next Review:** September 1, 2025  
**Maintainer:** Nexlinx Development Team